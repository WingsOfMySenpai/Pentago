import java.util.Random;

/**
 * Title:        Wuerfel
 * Description:  Modellklasse Wuerfel
 */



public class Wuerfel 
{
    private Random wuerfel;

    public Wuerfel() {
        wuerfel = new Random();
    }
  
    public int wuerfele() {
        return wuerfel.nextInt(6) + 1;
    }
}