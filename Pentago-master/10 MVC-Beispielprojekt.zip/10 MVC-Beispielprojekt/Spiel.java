/**
 * Title:           Modell
 * Description:     Modellklasse Spiel
 */

public class Spiel 
{
    private Spieler spieler1;
    private Spieler spieler2;
    private Wuerfel wuerfel;

    public Spiel() {
        spieler1    = new Spieler();
        spieler2    = new Spieler();
        wuerfel     = new Wuerfel();
    }

    public int spieler1Spielt() {
           spieler1.amZug(wuerfel);
           return spieler1.hatgewuerfelt();
    }
    
    public int spieler2Spielt() {
        spieler2.amZug(wuerfel);
        return spieler2.hatgewuerfelt();
    }
}