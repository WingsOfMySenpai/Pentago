import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

/**
 * Title:        View
 * Description:  Ein GUI f�r die exitierenden Modell-Klassen. Die View hat den Kontroller.
 */


public class View  extends JFrame 
{
    JPanel myJPanel             = new JPanel();
    
    BorderLayout myBorderLayout = new BorderLayout();
    
    JTextField spieler1TextField    = new JTextField();
    JTextField spieler2TextField    = new JTextField();
  
    JLabel jLabel1              = new JLabel();
    JLabel jLabel2              = new JLabel();
  
    JButton wuerfeln1Button     = new JButton();
    JButton stopButton          = new JButton();
    JButton wuerfeln2Button     = new JButton();

    public View() {
        SController myController= new SController(this);
        
        getContentPane().setLayout(myBorderLayout);
        myJPanel.setLayout(null);
        
        spieler1TextField.setBounds(36, 97, 125, 31);
        spieler2TextField.setBounds(new Rectangle(210, 97, 134, 31));
        
        jLabel1.setText("Spieler 1");
        jLabel1.setBounds(new Rectangle(49, 71, 106, 19));
        jLabel2.setText("Spieler 2");
        jLabel2.setBounds(new Rectangle(214, 70, 124, 24));
    
        wuerfeln1Button.setText("Wuerfeln");
        wuerfeln1Button.setBounds(new Rectangle(36, 148, 129, 38));
        wuerfeln1Button.setActionCommand("Wuerfeln_1");
        wuerfeln1Button.addActionListener(myController);

        stopButton.setText("Stop");
        stopButton.setBounds(new Rectangle(40, 249, 97, 46));
        stopButton.addActionListener(myController);                  
    
        wuerfeln2Button.setBounds(new Rectangle(215, 145, 129, 38));
        wuerfeln2Button.setText("Wuerfeln");
        wuerfeln2Button.addActionListener(myController);
        wuerfeln2Button.setActionCommand("Wuerfeln_2");
    
        myJPanel.setBackground(Color.orange);
        myJPanel.add(spieler1TextField, null);
        myJPanel.add(spieler2TextField, null);
        myJPanel.add(jLabel1, null);
        myJPanel.add(jLabel2, null);
        myJPanel.add(stopButton, null);
        myJPanel.add(wuerfeln1Button, null);
        myJPanel.add(wuerfeln2Button, null);
        
        this.getContentPane().add(myJPanel, BorderLayout.CENTER);
  }

}
