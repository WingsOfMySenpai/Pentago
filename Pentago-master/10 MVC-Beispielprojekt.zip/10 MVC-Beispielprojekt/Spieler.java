/**
 * Title:        Spieler
 * Description:  Modellklasse Spieler
 */

public class Spieler 
{

    private int punkte;
    private int augenzahl;

    public Spieler() {
        punkte      = 0;
        augenzahl   = 0;
    }

    public void amZug (Wuerfel Wuerfel) {
        augenzahl   = Wuerfel.wuerfele();
        punkte      = punkte + augenzahl;
    }

    public int hatgewuerfelt() {
        return augenzahl;
    }

    public int aktuellerPunkteStand() {
        return punkte;
    }
}