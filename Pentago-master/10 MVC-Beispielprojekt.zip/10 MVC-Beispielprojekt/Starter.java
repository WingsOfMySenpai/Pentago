/**
 * Title:        Starter
 * Description:  Diese Klasse dient zum Starten des gesamten Programms.
 */

public class Starter 
{
    public static void main(String[] args) 
    {
        View myView = new View();
        myView.setSize(500,400);
        myView.setVisible(true);

    }
}
