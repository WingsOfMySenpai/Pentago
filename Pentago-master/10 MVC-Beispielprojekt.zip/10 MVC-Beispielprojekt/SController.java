import java.awt.event.*;

/**
 * Title:           Controller
 * Description:     Dies ist der Controller dieses Spiels.
 *                  Der Controller hat das Spiel und kennt die View.
 */

public class SController implements ActionListener
{
    private View myView;
    Spiel game = new Spiel();

    public SController(View pView)
    {
        myView = pView;
    }

    public void actionPerformed (ActionEvent e)
    {
        String cmd = e.getActionCommand();
        
        if (cmd.equals("Wuerfeln_1")) 
        {
            myView.spieler1TextField.setText(Integer.toString(game.spieler1Spielt()));
        }
        else if (cmd.equals("Wuerfeln_2"))
        {
            myView.spieler2TextField.setText(Integer.toString(game.spieler2Spielt()));
        }
        else if (cmd.equals("Stop")) 
        {
            System.exit(0);
        }
  }
}

